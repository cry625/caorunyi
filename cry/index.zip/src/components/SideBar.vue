<template>
  <div class="container">sidebar</div>
  </template>
  <script setup>
  </script>
  <style scoped lang="css">
  .container{
    background: rgb(235, 233, 233);
    width: 100%;
    height: 100%;
  }
  </style>